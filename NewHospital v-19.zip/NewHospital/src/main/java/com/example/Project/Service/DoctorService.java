package com.example.Project.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import com.example.Project.Model.ViewAppointmentModel;


@Service
public class DoctorService {
	@Autowired
	JdbcTemplate jdbcTemplate;

	public List<ViewAppointmentModel> viewAppointments(String id) {
		List<ViewAppointmentModel> appointments = jdbcTemplate.query("select * from doctor_"+id+"Appointments;", new BeanPropertyRowMapper(ViewAppointmentModel.class));
		return appointments;
	}



	public void changeStatus(String doctorId, String id, String Status) {
		String sql3 = "select * from doctor_"+doctorId+"appointments where id ="+id;
		List<ViewAppointmentModel> user = jdbcTemplate.query(sql3, new BeanPropertyRowMapper(ViewAppointmentModel.class));
		String sql = "update doctor_"+doctorId+"appointments SET"+" Status =\""+Status+"\" "+ "where id=\""+id+"\";";
		String sql1 = "update patient_"+user.get(0).getPATID()+"appointments SET"+" Status =\""+Status+"\" "+ "where Time=\""+user.get(0).getTime()
		+"\" and Facility=\""+user.get(0).getFacility()
		+"\" and Date=\""+user.get(0).getDate()
		+"\" and Remarks=\""+user.get(0).getRemarks()+"\";";
		jdbcTemplate.execute(sql);
		jdbcTemplate.execute(sql1);
		
	}

}
